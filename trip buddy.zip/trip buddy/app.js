const lang = navigator.language.startsWith('en') ? 'en' : 'ar';

const t = {
  ar: {
    title: "🧠 مساعدك النفسي الشخصي",
    placeholder: "كيف تشعر اليوم؟",
    sad: "أشعر بحزنك. أنت أقوى مما تظن 🌈",
    anxious: "جرب تنفس 4-7-8 وخذ استراحة قصيرة 💚",
    insomnia: "جرب تقليل الإضاءة، تجنب الهاتف، وتمرين التنفس 🛌",
    happy: "رائع! انشر طاقتك الإيجابية! 😊",
    unknown: "شكرًا لمشاركتك! هل ترغب بتقرير؟ 📊",
    micError: "المتصفح لا يدعم التعرف على الصوت.",
    camError: "خطأ في الكاميرا: "
  },
  en: {
    title: "🧠 Your Personal Mental Assistant",
    placeholder: "How are you feeling today?",
    sad: "Sorry you're feeling down. You're stronger than you think 🌈",
    anxious: "Try 4-7-8 breathing. Take a short break 💚",
    insomnia: "Reduce lights, avoid phones, and breathe deeply 🛌",
    happy: "Awesome! Spread that good energy! 😊",
    unknown: "Thanks for sharing! Want a full report? 📊",
    micError: "Your browser doesn't support voice recognition.",
    camError: "Camera error: "
  }
}[lang];

document.getElementById("title").innerText = t.title;
document.getElementById("user-input").placeholder = t.placeholder;

const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");
const sendButton = document.getElementById("send-button");
let lastBotMsg = "";

sendButton.addEventListener("click", () => {
  const msg = userInput.value.trim();
  if (!msg) return;
  addMessage(msg, "user");
  userInput.value = "";
  const reply = analyzeEmotion(msg);
  setTimeout(() => {
    addMessage(reply, "bot");
    lastBotMsg = reply;
  }, 500);
});

function addMessage(text, sender) {
  const msg = document.createElement("div");
  msg.className = `message ${sender}-message`;
  msg.textContent = text;
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function analyzeEmotion(text) {
  const lower = text.toLowerCase();
  if (lower.includes("حزين") || lower.includes("sad")) return t.sad;
  if (lower.includes("قلق") || lower.includes("anxious")) return t.anxious;
  if (lower.includes("أرق") || lower.includes("insomnia")) return t.insomnia;
  if (lower.includes("سعيد") || lower.includes("happy")) return t.happy;
  return t.unknown;
}

function readLastMessage() {
  const utter = new SpeechSynthesisUtterance(lastBotMsg);
  utter.volume = 1;
  utter.lang = lang === "en" ? "en-US" : "ar-SA";
  speechSynthesis.speak(utter);
}

function startRecognition() {
  if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
    alert(t.micError);
    return;
  }
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SpeechRecognition();
  recognition.lang = lang === "en" ? "en-US" : "ar-SA";
  recognition.start();
  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    userInput.value = transcript;
    sendButton.click();
  };
}

let stream;
function startVideo() {
  navigator.mediaDevices.getUserMedia({ video: true })
    .then(s => {
      stream = s;
      document.getElementById("video").srcObject = s;
    })
    .catch(err => alert(t.camError + err));
}

function stopVideo() {
  if (stream) {
    stream.getTracks().forEach(track => track.stop());
    document.getElementById("video").srcObject = null;
  }
}

document.getElementById("theme-toggle").addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
});
